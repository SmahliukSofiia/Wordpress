<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'green_fair' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'green_fair' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'green_fair' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'cVl$RlzGLlp:P<Ya->5{$xgA;oF0[P+<!1J>Pya=tY%|@u1r|IR^VL%>H@Z|P|ej' );
define( 'SECURE_AUTH_KEY',  'T>`c++]I+SF&mWVFr(xiY=V?!l z|WmAd9eMKl42>I 4SYzu5Y;(bhrBo!?!g?U[' );
define( 'LOGGED_IN_KEY',    'IU=$hmk2W,T*ii6zBPOp67RFdezgUmNXH[d84Q@9~bW@v]9~DO$LY?[3jYP(9hJF' );
define( 'NONCE_KEY',        '$Ap=ty4=@kG4kbp$q8y4e|A`neGT |hG]ssZV|Hvhb;qdtfr[.P?*k4SfP)`;UJ)' );
define( 'AUTH_SALT',        'pBG-pwz[1y,qI> 96l2=P8&hp=j*6sI)8+y]&!5r`Xv=KAFF[ ;aVGf}t^$_H}(Y' );
define( 'SECURE_AUTH_SALT', 'fAS4s>5R#sU4`2SnLV-[Zpo3q!)gTredDV/Q]_P#C:GD3;M 1B+^pz  Xh@Sm-P_' );
define( 'LOGGED_IN_SALT',   '$ax.NQ_5{fzJY]4b@WadtzM0b-qhJCbq?[,vV3Ih$=ZXsYS}y-[M8DUr`Gioj<zW' );
define( 'NONCE_SALT',       '6GMOTayn`I?%*N[501[(W7/30)1uH^u=TyqK0#UpIs/$7R%$xUZ/U[vI~J4tCONa' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
